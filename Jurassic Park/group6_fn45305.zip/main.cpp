#include "Cage.h"
#include <fstream>

int main()
{
	/*Dinosaur* d = new Aquatic("Gosho", 'F', "Triassic", "Brontosaur");
	Dinosaur* c = new Aquatic;

	std::fstream file("ParkInfo.txt");
	std::cin >> *c;
	std::cout << *c;*/
	Cage cage("Large", "Terrestrial", "Triassic", "Flying");

	return 0;
}	